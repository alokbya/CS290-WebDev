// Import Dependencies
import React from "react";

function HomePage() {
    return (
        <>
            <article>
                <h2>Order your groceries</h2>
                <p>Navigate to other pages via the navigation bar above. You can create a shopping list, or view available stores.</p>
            </article>
        </>
    );
}

export default HomePage;