'use strict';
// Don't add or change anything above this comment.

/*
* Don't change the declaration of this function.
*/
const reducer1 = (previousValue, currentValue) => {
    //  Write your code here
};

/*
* Don't change the declaration of this function.
*/
const reducer2 = (previousValue, currentValue) => {
    //  Write your code here
};


// Don't add or change anything below this comment.
module.exports = { reducer1, reducer2 };